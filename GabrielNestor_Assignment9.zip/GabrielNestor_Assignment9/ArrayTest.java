//Gabriel Nestor
package Test;

public class ArrayTest {

	public static void main(String [] args) {
		String[] daysOfWeek = new String[7];
		daysOfWeek[0] = "Sunday";
		daysOfWeek[1] = "Monday";
		daysOfWeek[2] = "Tuesday";
		daysOfWeek[3] = "Wednesday";
		daysOfWeek[4] = "Thursday";
		daysOfWeek[5] = "Friday";
		daysOfWeek[6] = "Saturday";
		
		for(int i = 0; i <= 6; i++) {
			System.out.println(daysOfWeek[i]);
		}
		System.out.println(" ");
		set(daysOfWeek);
		gabesFavoriteOfAllTime(daysOfWeek);
	}
	static void set(String t[]) {
		String day;
		for (int i = 0; i < t.length; i++) {
			for (int j = i + 1; j < t.length; j++) {
				if(t[j].compareTo(t[i]) < 0) {
					day = t[i];
					t[i] = t[j];
					t[j] = day;
				}
			}
			System.out.println(t[i]);
		}
	}
	static void gabesFavoriteOfAllTime(String l[]) {
		System.out.println("Gabe Nestor's Favorite Day is: ");
		System.out.println(l[5]);
	}
}
