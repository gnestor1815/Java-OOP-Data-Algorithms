package Filecreator;
import java.util.Scanner;
import java.io.*;
public class directory_and_File {
   public static void main(String args[]) {
      System.out.println("Enter the path to create a directory: ");
      Scanner sc = new Scanner(System.in);
      String path = sc.next();
      System.out.println("Enter the name of the desired a directory: ");
      path = path+sc.next();
      //Creating a File object
      File file = new File(path);
      //Creating the directory
      boolean bool = file.mkdir();
      if(bool){
         System.out.println("Directory created successfully");
      }else{
         System.out.println("Sorry couldn�t create specified directory");
      }
      System.out.println("Write somethig to the file");
      String re = sc.nextLine();
      File FileA = new File(file.getAbsolutePath()+"/TxtFile.txt");
      try {
		FileWriter Writer = new FileWriter(file.getAbsolutePath() + "/TxtFile.txt");
		Writer.write(re);
		Writer.close();
	} catch (IOException e) {
		e.printStackTrace();
	}
      BufferedReader br = null;
	try {
		br = new BufferedReader(new FileReader(file.getAbsolutePath() + "/TxtFile.txt"));
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  String st;
  
  try {
	while ((st = br.readLine()) != null) {
	
	      System.out.println(st);
	}
} catch (IOException e) {
	e.printStackTrace();
}
  FileWriter fw;
try {
	
	fw = new FileWriter(FileA, true);
  BufferedWriter bw = new BufferedWriter(fw);
  bw.write("Long live Iron Man");
  bw.newLine();
  bw.close();
}
catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
try {
	while ((st = br.readLine()) != null) {
	
	      System.out.println(st);
	}
} catch (IOException e) {
	e.printStackTrace();
}
}
}