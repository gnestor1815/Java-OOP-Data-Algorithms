package Assignment;

import java.util.*;

public class Test {

	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("How much money do you have you made this year? ");
		double moneyAmount = input.nextDouble();
		int vaca = 0;
		vacationSpot(moneyAmount, vaca);
		goOrNo();
	}
	
	static void vacationSpot(double x, int y) {
		if (x <= 1000.00) {
			y = 1;
			System.out.println("Universal Studios");
		} else if (x <= 2000.00) {
			y = 2; 
			System.out.println("Hawaii Trip");
		} else if (x <= 3000.00) {
			y = 3;
			System.out.println("Disney");
		} else {
			y = 4;
			System.out.println("Go wherever you have the money for solo.");
		}
		switch (y) {
		case 1: 
			System.out.println("Packing list: \nClothes \nA Bag to carry around \nMoney \nClose-Toed Shoes \netc");
			break;
		case 2:
			System.out.println("Packing list: \nSwimming Clothes \nNormal clothes \nA Bag to carry around \nMoney \nClose-Toed Shoes \nSandals \netc");
			break;
		case 3:
			System.out.println("Packing list: \nClothes \nA Bag to carry around \nMoney \nClose-Toed Shoes \netc");
			break;
		case 4:
			System.out.println("Packing list: \nWhatever you want man.");
			break;
		default:
			break;
			
		}
	}
	
	static void goOrNo() {
		Scanner input = new Scanner(System.in);
		System.out.println("How many Vaca Days do you have?");
		int days = input.nextInt();
		boolean vey = days >= 10;
		String result =  vey ? "You have the recommended amount of days":"You dont have the recommended amount of days";
		System.out.println(result);
	}
	
}
