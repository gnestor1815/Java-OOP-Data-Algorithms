//Gabriel Nestor
package Assignment8;
import java.util.Scanner;
public class Main {

	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Give me a number:");
		int x = input.nextInt();
		System.out.println("Give me another number:");
		int y = input.nextInt();
		
		System.out.print(x);
		System.out.print(" + ");
		System.out.print(y);
		System.out.print(x);
		System.out.print(" + ");
		System.out.print(y);
		System.out.print("= ");
		System.out.println(x + y);
		
		System.out.print(x);
		System.out.print(" - ");
		System.out.print(y);
		System.out.print("= ");
		System.out.println(x - y);
		
		System.out.print(x);
		System.out.print(" * ");
		System.out.print(y);
		System.out.print("= ");
		System.out.println(x * y);
		
		System.out.print(x);
		System.out.print("/");
		System.out.print(y);
		System.out.print("= ");
		System.out.println(x/y);
		
		System.out.print("The Modulus of ");
		System.out.print(x);
		System.out.print(" and ");
		System.out.print(y);
		System.out.print(" = ");
		System.out.println(x%y);
		
		System.out.print(x);
		System.out.print(" increased by one is:");
		int v = ++x;
		System.out.println(v);
		
		System.out.print(x);
		System.out.print(" increased by one is:");
		int b = --x;
		System.out.println(b);
		
		System.out.print(x);
		System.out.print(" equals ");
		System.out.print(y);
		System.out.print(" is ");
		boolean q = x == y;
		System.out.println(q);
		
		System.out.print(x);
		System.out.print(" doesn't equal ");
		System.out.print(y);
		System.out.print(" is ");
		boolean w = x != y;
		System.out.println(w);
		
		System.out.print(x);
		System.out.print(" is less than ");
		System.out.print(y);
		System.out.print(" is ");
		boolean e = x < y;
		System.out.println(e);
		
		System.out.print(x);
		System.out.print(" is less than or equal to ");
		System.out.print(y);
		System.out.print(" is ");
		boolean r = x <= y;
		System.out.println(r);
		
		System.out.print(x);
		System.out.print(" is greater than ");
		System.out.print(y);
		System.out.print(" is ");
		boolean t = x > y;
		System.out.println(t);
		
		System.out.print(x);
		System.out.print(" is greater than or equal to ");
		System.out.print(y);
		System.out.print(" is ");
		boolean u = x >= y;
		System.out.println(u);
		
		System.out.print(q);
		System.out.print(" and ");
		System.out.print(w);
		System.out.print(" are ");
		System.out.println(q&w);
		
		System.out.print(q);
		System.out.print(" or ");
		System.out.print(w);
		System.out.print(" are ");
		System.out.println(q|w);
		
		System.out.print(q);
		System.out.print(" are different ");
		System.out.print(w);
		System.out.print(" is ");
		System.out.println(q^w);
		
		
		System.out.print(w);
		System.out.print(" is false is ");
		System.out.println(!w);
	}
	
}
