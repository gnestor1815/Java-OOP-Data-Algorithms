module GabrielNestor_Assignment8 {
	requires java.desktop;
}