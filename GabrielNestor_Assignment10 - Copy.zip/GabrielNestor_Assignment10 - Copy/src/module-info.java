module GabrielNestor_Assignment10 {
	requires java.desktop;
}