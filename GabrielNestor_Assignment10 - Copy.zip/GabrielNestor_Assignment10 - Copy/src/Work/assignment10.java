package Work;

import java.util.ArrayList;
import java.util.List;
import java.util.Dictionary;
import java.util.Hashtable;

public class assignment10 {
	
	public static void main(String[] args) {
		List<String> list1 = new ArrayList<>();
		list1.add("Yolo");
		list1.add("Pog");
		list1.add("UwU");
		list1.add("Lol");
		
		System.out.println(list1);
		
		Dict();
	}
	
	static void Dict() {
		Dictionary dict1 = new Hashtable();
		dict1.put("Legos", "A fun toy for all ages");
		dict1.put("Minecraft", "Yet another game for all ages");
		dict1.put("Trix", "SPECIFICALLY FOR KIDS");
		
		
	System.out.println("Definition of Legos: " + dict1.get("Legos"));
	System.out.println("Definition of Minecraft: " + dict1.get("Minecraft"));
	System.out.println("Definition of Trix: " + dict1.get("Trix"));
		}
	
	
	
	
}
